<?php
echo "<html>\n";
echo " <head>\n";
echo "   <title>逐梦-646班-鲸宝服务器</title>\n";
echo " </head>\n";
echo "   <body>\n";
echo "     代码区:\n";
echo "跑马灯@加油 646 加油加油 646 加油加油 646 加油加油 646 加油加油 646 加油加油 646 加油@跑马灯\n";
echo "最新公告@646班APP，本人正在努力学习更高级的功能，敬请期待。正在测试中.....公告暂未最新通知。@最新公告\n";
echo "作业@没事写什么作业？作业很多要靠自己的努力@作业\n";
echo "历史公告@http://love.fa37y.cn/646/www/@历史公告\n";
echo "历史作业@http://love.fa37y.cn/646/www/@历史作业\n";
echo "优秀语文作业@http://love.fa37y.cn/646/www/@优秀语文作业\n";
echo "优秀数学作业@http://love.fa37y.cn/646/www/@优秀数学作业\n";
echo "优秀英语作业@http://love.fa37y.cn/646/www/@优秀英语作业\n";
echo "优秀专业作业@http://love.fa37y.cn/646/www/@优秀专业作业\n";
echo "排名@1.龙莹\n2.陈佳辉\n3.周文茜\n4.李文俊\n5.张自强\n6.桂兴发\n7.邓艺翔\n8.张佳荣\n9.李小慧\n10.谢月红\n@排名\n";
echo "成绩@http://love.fa37y.cn/646/www/cj.htm@成绩\n";
echo "扣分@http://love.fa37y.cn/646/www/@扣分\n";
echo "     :代码区\n";
echo "   </body>\n";
echo "/html>\n";
?>
