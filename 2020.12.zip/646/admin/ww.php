<?php
echo "<html>\n";
echo " <head>\n";
echo "   <title>逐梦-646班</title>\n";
echo " </head>\n";
echo "   <body>\n";
echo "     代码区:\n";
echo "座位表@http://love.fa37y.cn/646/www/@座位表\n";
echo "作息表@http://love.fa37y.cn/646/www/@作息表\n";
echo "课程表@http://love.fa37y.cn/646/www/@课程表\n";
echo "考号@http://love.fa37y.cn/646/www/@考号\n";
echo "卫生表@http://love.fa37y.cn/646/www/@卫生表\n";
echo "     :代码区\n";
echo "   </body>\n";
echo "/html>\n";
?>