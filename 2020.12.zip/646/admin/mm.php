<?php
echo "<html>\n";
echo " <head>\n";
echo "   <title>逐梦-646班</title>\n";
echo " </head>\n";
echo "   <body>\n";
echo "     代码区:\n";
echo "卡密@646006@卡密\n";
echo "验证码@646wangbiao@验证码\n";
echo "管理@646wangbiao@管理\n";
echo "vip@王彪@vip\n";
echo "     :代码区\n";
echo "   </body>\n";
echo "/html>\n";
?>