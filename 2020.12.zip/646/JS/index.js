function time(){
    var date=new Date();
    var time=date.getHours();
    var nowtime=time<1?"midnight":time<6?"after dawn":time<10?"morning":time<14?"noon":time<18?"afternoon":time<23?"evening":"midnight";
    switch(nowtime){
        case"after dawn":
            alert("�賿��!");
            break;
        case"morning":
            alert("���Ϻ�!");
            break;
        case"noon":
            alert("�����!");
            break;
        case"afternoon":
            alert("�����!");
            break;
        case"evening":
            alert("���Ϻ�!");
            break;
        case"midnight":
            alert("��ҹ��!");
            break;
       
    
    }

}

function start(){
	var now=Date();
	var hr=now.getHours();
	var min=now.getMinutes();
	var sec=now.getSeconds();
	var clocktext="����ʱ��:"+"hr"+":"+"min"+":"+"sec"; 
	var timeID=document.getElementById("timeArea");
	timeID.innerText=clocktext;

}window.setInterval("start()",1000);
